from fastapi import APIRouter
from models.request import Request
from config.database import request_collection
from schema.request import list_serializer
from bson import ObjectId

router = APIRouter()

@router.get("/request/")
async def get_requests():
    return list_serializer(request_collection.find())
    
@router.post("/request/create")
async def post_request(request: Request):
    request_collection.insert_one(dict(request))  

@router.put("/request/{id}")
async def put_request(id: str, request: Request):
    request_collection.find_one_and_update({"_id": ObjectId(id)}, {"$set": dict(request)})

@router.delete("/request/{id}")
async def delete_request(id: str):
    request_collection.find_one_and_delete({"_id": ObjectId(id)})