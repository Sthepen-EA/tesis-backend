from pydantic import BaseModel

class Request (BaseModel):
    title: str
    description: str
    status: bool