from pydantic import BaseModel

class Prediction (BaseModel):
    price: float
    name: str



