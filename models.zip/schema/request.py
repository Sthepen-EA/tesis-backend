def individual_serializer(request) -> dict:
    return {
        # _ its because mongo has and specific way finding a column 
        "id": str(request["_id"]),
        "title": request["title"],
        "description": request["description"],
        "status": request["status"],
    }

def list_serializer(requests) -> list:
    return [individual_serializer(request) for request in requests]