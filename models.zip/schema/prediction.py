def individual_serializer(cost_prediction) -> dict:
    return {
        # _ its because mongo has and specific way finding a column 
        "id": str(cost_prediction["_id"]),
        "name": cost_prediction["name"],
        "price": cost_prediction["price"]
    }

def list_serializer(cost_predictions) -> list:
    return [individual_serializer(cost_prediction) for cost_prediction in cost_predictions]
